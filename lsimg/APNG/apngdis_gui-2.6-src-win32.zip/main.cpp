/* APNG Disassembler 2.6
 *
 * Deconstructs APNG files into a sequence of individual PNG frames.
 *
 * http://apngdis.sourceforge.net/
 *
 * Copyright (c) 2010-2013 Max Stepin
 * maxst at users.sourceforge.net
 *
 * zlib license
 * ------------
 *
 * This software is provided 'as-is', without any express or implied
 * warranty.  In no event will the authors be held liable for any damages
 * arising from the use of this software.
 *
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, and to alter it and redistribute it
 * freely, subject to the following restrictions:
 *
 * 1. The origin of this software must not be misrepresented; you must not
 *    claim that you wrote the original software. If you use this software
 *    in a product, an acknowledgment in the product documentation would be
 *    appreciated but is not required.
 * 2. Altered source versions must be plainly marked as such, and must not be
 *    misrepresented as being the original software.
 * 3. This notice may not be removed or altered from any source distribution.
 *
 */
#include <windows.h>
#include <commctrl.h>
#include <stdio.h>
#include "resource.h"

HINSTANCE   hInst;
HICON       hIconMain;
HWND        hMainDlg;
wchar_t     szInput[MAX_PATH+1];
wchar_t     szOutPrefix[MAX_PATH+1];

typedef struct { wchar_t * szInput; wchar_t * szOutPrefix; } FUNC_PARAMS, *PFUNC_PARAMS;
PFUNC_PARAMS  pParams;
HANDLE        hConvertThread;
DWORD         dwThreadId;
DWORD WINAPI  ConvertFunction(LPVOID lpParam);

void SetInputOutput()
{
  SetDlgItemText(hMainDlg, IDC_EDIT_INPUT, szInput);
  if (szOutPrefix[0] == 0)
  {
    wcscpy(szOutPrefix, L"apngframe");
    SetDlgItemText(hMainDlg, IDC_EDIT_OUTPUT, szOutPrefix);
  }
  SendDlgItemMessage(hMainDlg, IDC_PROGRESS1, PBM_SETPOS, 0, 0);
  SetDlgItemText(hMainDlg, IDC_PERCENT, L"");
  EnableWindow(GetDlgItem(hMainDlg, IDC_BUTTON_CONVERT), TRUE);
  SetFocus(GetDlgItem(hMainDlg, IDC_BUTTON_CONVERT));
}

void BrowseInput()
{
  OPENFILENAME  ofn;
  ZeroMemory(&ofn, sizeof(ofn));
  ofn.lStructSize = sizeof(OPENFILENAME);
  ofn.hwndOwner = hMainDlg;
  ofn.hInstance = hInst;
  ofn.lpstrFilter = L"Animated PNG Files (*.png)\0*.png\0";
  ofn.nFilterIndex = 1;
  ofn.lpstrFile = szInput;
  ofn.nMaxFile = MAX_PATH;
  ofn.lpstrTitle = L"Animated PNG Input";
  ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST;
  ofn.lpstrDefExt = L"png";

  if (GetOpenFileName(&ofn))
  {
    SetInputOutput();
  }
}

void DropFiles(HDROP hDrop)
{
  if (DragQueryFile(hDrop, -1, 0, 0) != 0)
  {
    if (DragQueryFile(hDrop, 0, 0, 0) <= MAX_PATH)
    {
      if (DragQueryFile(hDrop, 0, szInput, MAX_PATH+1) != 0)
      {
        SetInputOutput();
      }
    }
  }
}

LRESULT CALLBACK MainDlgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
  switch (uMsg)
  {
    case WM_INITDIALOG:
      hMainDlg = hWnd;
      SendMessage(hWnd, WM_SETICON, ICON_BIG, (LPARAM)hIconMain);
      SendDlgItemMessage(hWnd, IDC_PROGRESS1, PBM_SETRANGE, 0, MAKELPARAM(0, 48));
      SendDlgItemMessage(hWnd, IDC_PROGRESS1, PBM_SETPOS, 0, 0);
      SetDlgItemText(hWnd, IDC_PERCENT, L"");
      if (szInput[0] != 0)
      {
        SetInputOutput();
      }
      DragAcceptFiles(hWnd, TRUE);
      return TRUE;
    case WM_CLOSE:
      DragAcceptFiles(hWnd, FALSE);
      EndDialog(hWnd, IDCANCEL);
      PostQuitMessage(0);
      return TRUE;
    case WM_COMMAND:
      switch (HIWORD(wParam))
      {
        case BN_CLICKED:
          switch (LOWORD(wParam))
          {
            case IDC_BUTTON_BROWSE_INPUT:
              BrowseInput();
              return TRUE;
            case IDC_BUTTON_CONVERT:
              GetDlgItemText(hWnd, IDC_EDIT_INPUT,  szInput,     MAX_PATH);
              GetDlgItemText(hWnd, IDC_EDIT_OUTPUT, szOutPrefix, MAX_PATH);
              if (szInput[0] != 0 && szOutPrefix[0] != 0)
              {
                pParams->szInput = szInput;
                pParams->szOutPrefix = szOutPrefix;
                hConvertThread = CreateThread(NULL, 0, ConvertFunction, pParams, 0, &dwThreadId);
              }
              return TRUE;
            case IDCANCEL:
              DragAcceptFiles(hWnd, FALSE);
              EndDialog(hWnd, IDCANCEL);
              PostQuitMessage(0);
              return TRUE;
            default:
              return FALSE;
          }
        case EN_CHANGE:
          switch (LOWORD(wParam))
          {
            case IDC_EDIT_INPUT:
            case IDC_EDIT_OUTPUT:
              GetDlgItemText(hMainDlg, IDC_EDIT_INPUT,  szInput,     MAX_PATH);
              GetDlgItemText(hMainDlg, IDC_EDIT_OUTPUT, szOutPrefix, MAX_PATH);
              EnableWindow(GetDlgItem(hMainDlg, IDC_BUTTON_CONVERT), szInput[0] != 0 && szOutPrefix[0] != 0);
              SendDlgItemMessage(hMainDlg, IDC_PROGRESS1, PBM_SETPOS, 0, 0);
              SetDlgItemText(hMainDlg, IDC_PERCENT, L"");
              return TRUE;
            default:
              return FALSE;
          }
        default:
          return FALSE;
      }
    case WM_DROPFILES:
      DropFiles((HDROP)wParam);
      return TRUE;
    default:
      return FALSE;
  }
}

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PWSTR pCmdLine, int nCmdShow)
{
  INITCOMMONCONTROLSEX icce;
  icce.dwSize = sizeof(icce);
  icce.dwICC = ICC_PROGRESS_CLASS;
  InitCommonControlsEx(&icce);
  hInst = hInstance;
  hIconMain = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_MAIN));

  LPWSTR * szArglist;
  int nArgs;

  szArglist = CommandLineToArgvW(GetCommandLineW(), &nArgs);
  if (szArglist != NULL)
  {
    wcscpy(szInput, (nArgs > 1) ? szArglist[1] : L"");
    LocalFree(szArglist);
  }

  pParams = (PFUNC_PARAMS)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(FUNC_PARAMS));
  if (pParams != NULL)
  {
    DialogBox(hInstance, MAKEINTRESOURCE(IDD_MAIN), NULL, (DLGPROC)MainDlgProc);
    CloseHandle(hConvertThread);
    HeapFree(GetProcessHeap(), 0, pParams);
  }

  return FALSE;
}
