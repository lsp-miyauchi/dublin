#include "stdafx.h"
#include "lsimg.h"
#include "common.h"

#define HAVE_BOOLEAN


////////////////////////////////////////////////////////////////////////
//

#ifdef __cplusplus
extern "C" {                    // Assume C declarations for C++
#endif

#include "jpgcode.h"			// Common decls for cjpeg/djpeg applications
#include "jversion.h"			// for version message

#ifdef __cplusplus
}
#endif

EXTERN(void) jpeg_mf_stdio_src JPP((j_decompress_ptr cinfo, LPMF infile, int orientation));
EXTERN(void) jpeg_mf_stdio_dest JPP((j_compress_ptr cinfo, LPMF outfile));


////////////////////////////////////////////////////////////////////////
// Create the add-on message string table.

#define JMESSAGE(code,string)	string ,

static const char * const cdjpeg_message_table[] = {
#include "jpgerr.h"
  NULL
};

// quality          = 0 - 100
// dct_method       = JC_ISLOW / JC_IFAST / JC_FLOAT
// smoothing_factor = 0 - 100

METHODDEF(boolean)
jd_com_handler(j_decompress_ptr cinfo)
{
	return TRUE;
}

void je_setswitches(j_compress_ptr cinfo, JPEG_CPARAMS* pjc)
{
	int q_scale_factor;					// scaling percentage for -qtables
	boolean force_baseline;
	jpeg_component_info * compptr;

	// Set up default JPEG parameters.
	// Note that default -quality level need not, and does not,
	// match the default scaling for an explicit -qtables argument.
	q_scale_factor = 100;				// default to no scaling for -qtables
	force_baseline = FALSE;				// by default, allow 16-bit quantizers
	cinfo->err->trace_level = 0;

	// Scan command line options, adjust parameters
	// �Z�p�R�[�f�B���O
//@	cinfo->arith_code = TRUE;

	// �x�[�X���C���o��
	force_baseline = (pjc->baseline != 0);

	// DCT�A���S���Y�� ... JC_ISLOW / JC_IFAST / JC_FLOAT
	cinfo->dct_method = (J_DCT_METHOD)pjc->dct;

	// �O���[�X�P�[���o��
	if (pjc->grayscale)
		jpeg_set_colorspace(cinfo, JCS_GRAYSCALE);

	// �G���g���s�[�I�v�e�B�}�C�Y
//@	cinfo->optimize_coding = TRUE;

	// �N�I���e�B�t�@�N�^
	q_scale_factor = jpeg_quality_scaling(pjc->quality);

	// �X���[�W���O�t�@�N�^
	cinfo->smoothing_factor = pjc->smooth;

	// �v���O���b�V�u
	BOOL simple_progressive = pjc->progressive;

	// �I�����ꂽ�i���̂��߂̌��F�e�[�u����ݒ�
	// Some or all may be overridden if -qtables is present.
	jpeg_set_quality(cinfo, pjc->quality, force_baseline);

	if (simple_progressive)
		jpeg_simple_progression(cinfo);

	// �T���v�����O�t�@�N�^ �� �d�v ��
	compptr = &cinfo->comp_info[0];
	compptr->h_samp_factor = 1;
	compptr->v_samp_factor = 1;
}

extern "C"
HGLOBAL WINAPI imgJpgSaveMemParamsSt(HDIB hdib, JPEG_CPARAMS* pjc, DWORD* pdwSize)
{
	struct jpeg_compress_struct cinfo;
	struct jpeg_error_mgr jerr;
	cjpeg_source_ptr src_mgr;
	JDIMENSION num_scanlines;
	BOOL bOK = FALSE;
	LPMF pmf = NULL;
	HGLOBAL hmem = NULL;

	mif* image = new mif();
	if (!image->attachdib(hdib)) {
		delete image;
		return NULL;
	}

	// JPEG���k�I�u�W�F�N�g�̏�����
	cinfo.err = jpeg_std_error(&jerr);
	jpeg_create_compress(&cinfo);

	// �I���W�i���f�[�^�̊i�[
	cinfo.write_LSP_marker = FALSE;
	cinfo.client_data = pjc->cdata;
	if (pjc->cdata)
		cinfo.write_LSP_marker = TRUE;

	// Add some application-specific error messages (from cderror.h)
	jerr.addon_message_table = cdjpeg_message_table;
	jerr.first_addon_message = JMSG_FIRSTADDONCODE;
	jerr.last_addon_message = JMSG_LASTADDONCODE;

	cinfo.in_color_space = JCS_RGB; 			// JCS_RGB�Ɓi����Ɂj����
	jpeg_set_defaults(&cinfo);

	// �p�����^�ݒ�
	cinfo.my_image = image;
	je_setswitches(&cinfo, pjc);

	// �o�̓t�@�C�����J��
	int packets = image->m_packets * 3;
	pmf = _mfnew(packets);
	if (!pmf)
		goto exit_jpg;

	// Figure out the input file format, and set up to read it.
	src_mgr = jinit_read_image(&cinfo);

	// Read the input file header to obtain file size & colorspace.
	(*src_mgr->start_input)(&cinfo, src_mgr);

	// Now that we know input colorspace, fix colorspace-dependent defaults
	jpeg_default_colorspace(&cinfo);

	// �p�����^�Đݒ�
	je_setswitches(&cinfo, pjc);

	// Specify data destination for compression
	jpeg_mf_stdio_dest(&cinfo, pmf);

	// ���k�J�n
	jpeg_start_compress(&cinfo, TRUE);

	// �f�[�^����
	while (cinfo.next_scanline < cinfo.image_height)
	{
		num_scanlines = (*src_mgr->get_pixel_rows)(&cinfo, src_mgr);
		jpeg_write_scanlines(&cinfo, src_mgr->buffer, num_scanlines);
	}

	// ���k�̏I��
	(*src_mgr->finish_input)(&cinfo, src_mgr);
	jpeg_finish_compress(&cinfo);

	hmem = _mfdetach(pmf, pdwSize);
	bOK = TRUE;

exit_jpg:
	jpeg_destroy_compress(&cinfo);
	delete image;
	return hmem;
}

extern "C"
HGLOBAL WINAPI imgJpgSaveMemParams(HDIB hdib, int quality, int dct, int smooth, void* cdata, DWORD* pdwSize)
{
	JPEG_CPARAMS jc;
	jc.quality = quality;
	jc.dct = dct;
	jc.smooth = smooth;
	jc.progressive = FALSE;
	jc.baseline = FALSE;
	jc.grayscale = FALSE;
	jc.cdata = cdata;
	return imgJpgSaveMemParamsSt(hdib, &jc, pdwSize);
}

extern "C"
BOOL WINAPI imgJpgSaveParamsSt(LPCTSTR pFile, HDIB hdib, JPEG_CPARAMS* pjc)
{
	DWORD dwSize;
	HGLOBAL hmem = imgJpgSaveMemParamsSt(hdib, pjc, &dwSize);
	return SaveMemToFileAndWep(pFile, hmem, dwSize);
}

extern "C"
BOOL WINAPI imgJpgSaveParams(LPCTSTR pFile, HDIB hdib, int quality, int dct, int smooth, void* cdata)
{
	JPEG_CPARAMS jc;
	jc.quality = quality;
	jc.dct = dct;
	jc.smooth = smooth;
	jc.progressive = FALSE;
	jc.baseline = FALSE;
	jc.grayscale = FALSE;
	jc.cdata = cdata;
	return imgJpgSaveParamsSt(pFile, hdib, &jc);
}

extern "C"
HGLOBAL WINAPI imgJpgSaveMem(HDIB hdib, int quality, int dct, int smoothing, DWORD* pdwSize)
{
	return imgJpgSaveMemParams(hdib, quality, dct, smoothing, NULL, pdwSize);
}

extern "C"
BOOL WINAPI imgJpgSave(LPCTSTR pszFile, HDIB hDIB, int quality, int dct, int smoothing)
{
	return imgJpgSaveParams(pszFile, hDIB, quality, dct, smoothing, NULL);
}

static void jd_setswitches(j_decompress_ptr cinfo, int color, int scale, int dct, int dither, BOOL smoothing)
{
	cinfo->err->trace_level = 0;

	if (color) {
		cinfo->desired_number_of_colors = color;
		cinfo->quantize_colors = TRUE;
	}

	// IDCT�A���S���Y���̐ݒ�
	//     JC_ISLOW / JC_IFAST / JC_FLOAT
	cinfo->dct_method = (J_DCT_METHOD)dct;

	// �f�B�U�����O�̐ݒ�
	//     JD_FS / JD_NONE / JD_ORDERED
	cinfo->dither_mode = (J_DITHER_MODE)dither;

	// �X���[�W���O
	cinfo->do_fancy_upsampling = (smoothing != 0);

	// �o�̓X�P�[���̐ݒ�
	cinfo->scale_num = 1;
	cinfo->scale_denom = scale;
	if (scale > 1)
		cinfo->two_pass_quantize = FALSE;
}

#define INTEL(a)	((a)==0x4949)

static int get_orientation(LPMF pmf)
{
	long base = _mftell(pmf);
	short order = _mfgetw(pmf);
	_mfgetw(pmf);			// Should be 42 for standard TIFF

	while (!_mfeof(pmf)) {
		long doff = INTEL(order) ? _mfgetl(pmf) : _mfgetl_be(pmf);
		if (!doff) break;

		_mfseek(pmf, doff + base, SEEK_SET);

		int entries = INTEL(order) ? _mfgetw(pmf) : _mfgetw_be(pmf);
		if (entries > 512) break;

		while (entries--) {
			if (_mfeof(pmf)) break;

			long save = _mftell(pmf);
			int tag = INTEL(order) ? _mfgetw(pmf) : _mfgetw_be(pmf);
			if (tag == 0x112) {
				_mfgetw(pmf);			// type (is USHORT)
				_mfgetl(pmf);			// count (is 1)
				int orientation = INTEL(order) ? _mfgetw(pmf) : _mfgetw_be(pmf);
				return orientation;
			}
			_mfseek(pmf, save + 12, SEEK_SET);
		}
	}
	return ORI_NONE;
}

static int jpeg_get_exif_orientation(LPMF pmf)
{
	int orientation = ORI_NONE;
	_mfseek(pmf, 2, SEEK_SET);
	BYTE hdr[32];
	while (_mfread(pmf, hdr, 4) == 4) {
		if (hdr[0] != 0xff || hdr[1] < 0xd0 || hdr[1] == 0xd9)
			break;

		if (hdr[1] == 0xe1) {
			if (_mfread(pmf, hdr, 6) != 6)
				break;

			if (!memcmp(hdr, "Exif\0\0", 6)) {
				orientation = get_orientation(pmf);
				break;
			}
		}
		_mfseek(pmf, (hdr[2] << 8) + hdr[3] - 2, SEEK_CUR);
	}
	return orientation;
}

extern "C"
HDIB WINAPI imgJpgLoadMemParams(HGLOBAL hmem, int colors, int scale, int dct, int dither, BOOL smoothing)
{
	struct jpeg_decompress_struct cinfo;
	struct jpeg_error_mgr jerr;
	djpeg_dest_ptr dest_mgr = NULL;
	LPMF pmf = NULL;
	JDIMENSION num_scanlines;
	HDIB hdib = NULL;

	// Initialize the JPEG decompression object with default error handling.
	cinfo.err = jpeg_std_error(&jerr);
	jpeg_create_decompress(&cinfo);

	// Add some application-specific error messages (from cderror.h)
	jerr.addon_message_table = cdjpeg_message_table;
	jerr.first_addon_message = JMSG_FIRSTADDONCODE;
	jerr.last_addon_message = JMSG_LASTADDONCODE;

	// Insert custom COM marker processor.
	jpeg_set_marker_processor(&cinfo, JPEG_COM, jd_com_handler);

	// �W�J�̂��߂̊e��X�C�b�`�̐ݒ�
	jd_setswitches(&cinfo, colors, scale, dct, dither, (smoothing != 0));

	// JPEG�������t�@�C�����J��
	pmf = _mfmemopen(hmem, 0);
	if (!pmf)
		goto exit_jpg;

	// JPEG�t�@�C������
	if (_mfgetw_ns(pmf) != 0xD8FF) {
		// �}�b�N�o�C�i������
		_mfseek(pmf, 128, FILE_BEGIN);
		if (_mfgetw_ns(pmf) != 0xD8FF) {
			_mfclose(pmf);
			goto exit_jpg;
		}
	}

	// �摜�̌������擾(ver7)
	int orientation = ORI_NONE;
	if (isVer7()) {
		long pos = _mftell(pmf);
		orientation = jpeg_get_exif_orientation(pmf);
		_mfseek(pmf, pos, SEEK_SET);
	}

	// �W�J�f�[�^�\�[�X��ݒ�
	jpeg_mf_stdio_src(&cinfo, pmf, orientation);

	// �t�@�C���w�b�_�̓ǂݍ���
	jpeg_read_header(&cinfo, TRUE);

	// �W�J�̂��߂̊e��X�C�b�`�̍Đݒ�
	jd_setswitches(&cinfo, colors, scale, dct, dither, smoothing);

	// �o�̓��W���[���̏�����
	dest_mgr = jinit_write_image(&cinfo);
	if (dest_mgr == NULL)
		goto exit_jpg;

	// �W�J�J�n
	jpeg_start_decompress(&cinfo);

	// Write output file header
	(*dest_mgr->start_output)(&cinfo, dest_mgr);
	if (!cinfo.my_image)
		goto exit_jpg;

	// �f�[�^����
	while (cinfo.output_scanline < cinfo.output_height) {
		num_scanlines = jpeg_read_scanlines(&cinfo, dest_mgr->buffer, dest_mgr->buffer_height);
		if (num_scanlines < 1)
			break;
		(*dest_mgr->put_pixel_rows)(&cinfo, dest_mgr, num_scanlines);
	}

	// �W�J�I��
	(*dest_mgr->finish_output)(&cinfo, dest_mgr);
	jpeg_finish_decompress(&cinfo);
	_mfclose(pmf);
	CDibHandle* dib = (CDibHandle*)cinfo.my_image;
	if (dib) {
		hdib = dib->Detach();
		delete dib;
	}

exit_jpg:
	jpeg_destroy_decompress(&cinfo);
	return hdib;
}

extern "C"
HDIB WINAPI imgJpgLoadMem(HGLOBAL hmem, int colors, int scale)
{
	return imgJpgLoadMemParams(hmem, colors, scale, JC_ISLOW, JD_NONE, FALSE);
}

extern "C"
HDIB WINAPI imgJpgLoadParams(LPCTSTR pszFile, int colors, int scale, int dct, int dither, int smoothing)
{
	DWORD dw;
	HDIB hdib;
	HGLOBAL hmem = readfileall(pszFile, &dw);
	if (!hmem)
		return NULL;

	hdib = imgJpgLoadMemParams(hmem, colors, scale, dct, dither, smoothing);
	GlobalFree(hmem);
	return hdib;
}

extern "C"
HDIB WINAPI imgJpgLoad(LPCTSTR pszFile, int colors, int scale)
{
	return imgJpgLoadParams(pszFile, colors, scale, JC_ISLOW, JD_FS, FALSE);
}

extern "C"
HDIB WINAPI imgJpgLoadScaled(LPCTSTR pszFile, int xmax, int ymax, int colors, int dct, int dither, int smoothing)
{
	int x, y;
	if (!imgJpgGetImageSize(pszFile, &x, &y, NULL))
		return NULL;

	int scale;
	for (scale = 1; scale <= 8; scale <<= 1) {
		if (x <= xmax && y <= ymax)
			break;
		x >>= 1;
		y >>= 1;
	}

	return imgJpgLoadParams(pszFile, colors, scale, dct, dither, smoothing);
}

BYTE 
a0[] = {  0x14, 0x17, 0x16, 0x11, 0x10, 0x13, 0x12, 0x1d,
          0x1c, 0x1f, 0x1e, 0x19, 0x18, 0x1b, 0x1a, 0x05,
          0x04, 0x07, 0x06, 0x01, 0x00, 0x03, 0x02, 0x0d,
          0x0c, 0x0f },
a1[] = {  0x02, 0x01, 0x00, 0x07, 0x06, 0x05, 0x04, 0x0b,
          0x0a, 0x09, 0x08, 0x0f, 0x0e, 0x0d, 0x0c, 0x13,
          0x12, 0x11, 0x10, 0x17, 0x16, 0x15, 0x14, 0x1b,
          0x1a, 0x19 },
a2[] = {   0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 0x00,
           0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x18,
           0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f, 0x10,
           0x11, 0x12 },
a3[] = {   0x08, 0x0b, 0x0a, 0x0d, 0x0c, 0x0f, 0x0e, 0x01,
           0x00, 0x03, 0x02, 0x05, 0x04, 0x07, 0x06, 0x19,
           0x18, 0x1b, 0x1a, 0x1d, 0x1c, 0x1f, 0x1e, 0x11,
           0x10, 0x13 },
a4[] = {   0x34, 0x37, 0x36, 0x31, 0x30, 0x33, 0x32, 0x3d,
           0x3c, 0x3f, 0x3e, 0x39, 0x38, 0x3b, 0x3a, 0x25,
           0x24, 0x27, 0x26, 0x21, 0x20, 0x23, 0x22, 0x2d,
           0x2c, 0x2f },
a5[] = {   0x0f, 0x0c, 0x0d, 0x0a, 0x0b, 0x08, 0x09, 0x06,
           0x07, 0x04, 0x05, 0x02, 0x03, 0x00, 0x01, 0x1e,
           0x1f, 0x1c, 0x1d, 0x1a, 0x1b, 0x18, 0x19, 0x16,
           0x17, 0x14 },
a6[] = {   0x2a, 0x29, 0x28, 0x2f, 0x2e, 0x2d, 0x2c, 0x23,
           0x22, 0x21, 0x20, 0x27, 0x26, 0x25, 0x24, 0x3b,
           0x3a, 0x39, 0x38, 0x3f, 0x3e, 0x3d, 0x3c, 0x33,
           0x32, 0x31 },
a7[] ={   0x0e, 0x0d, 0x0c, 0x0b, 0x0a, 0x09, 0x08, 0x07,
          0x06, 0x05, 0x04, 0x03, 0x02, 0x01, 0x00, 0x1f,
          0x1e, 0x1d, 0x1c, 0x1b, 0x1a, 0x19, 0x18, 0x17,
          0x16, 0x15 };

BYTE* angou0[] = {a6, a3, a0, a1, a2, a3, a4, a1, a2, a3, a5, a7, a6, a3, a0, a1},
    * angou1[] = {a2, a3, a4, a1, a2, a3, a5, a7, a6, a3, a0, a1, a2, a3, a4, a1},
    * angou2[] = {a2, a3, a5, a7, a6, a3, a0, a1, a2, a3, a4, a1, a2, a3, a5, a7};

static int getcpcode(HANDLE hf, LPSTR pszCode)
{
	DWORD dw;
	BYTE code[48 + 128];
	int len, i, j, k;
	char buf[MAX_PATH];
	BYTE *p, *pa, ch, **pArray;

	*pszCode = '\0';
	SetFilePointer(hf, 0x14, NULL, FILE_BEGIN);
	if (!ReadFile(hf, code, 48 + 128, &dw, NULL) || dw < 48)
		return 0;

	len = 0;
	for (j = 0; j < 3; j++) {
		p = code + j * 16;
		if (j == 0)
			pArray = angou0;
		else if (j == 1)
			pArray = angou1;
		else
			pArray = angou2;

		for (i = 0; i < 16; i++) {
			ch = p[i];
			pa = pArray[i];
			for (k = 0; k < 26; k++) {
				if (pa[k] == ch)
					break;
			}
			if (k >= 26)
				break;

			buf[i] = (char)(k + 'A');
		}
		buf[i] = '\0';
		if (i < 1)
			break;
		len += wsprintfA(&pszCode[len], "[%s]", buf);
	}
	return (int)strlen(pszCode);
}

#if 0
static int getcpcode2(HANDLE hf, LPSTR pszCode)
{
	static BYTE CP_KEY[] = "kIUCHIuCHINO";
	DWORD dw;
	BYTE code[48 + 128], *cp, *wp;
	char buf[64];
	int i, j, len;

	*pszCode = '\0';

	SetFilePointer(hf, 0x14, NULL, FILE_BEGIN);
	if (!ReadFile(hf, code, 48 + 128, &dw, NULL) || dw < 48)
		return 0;

	cp = CP_KEY;
	wp = code;
	for (j = 0; j < 3; j++) {
		for (i = 0; i < 16; i++) {
            if (*wp != '\0')
				*wp ^= *cp;
			wp++;
			cp++;
			if (*cp == '\0')
				cp = CP_KEY;
		}
	}

	len = 0;
	for (j = 0; j < 3; j++) {
		cp = code + j * 16;
		for (i = 0; i < 16; i++) {
			if (isalpha(cp[i]))
				buf[i] = cp[i];
			else
				break;
		}
		buf[i] = '\0';
		if (i < 1)
			break;
		len += wsprintfA(&pszCode[len], "[%s]", buf);
	}
	return (int)strlen(pszCode);
}
#endif

static BOOL jpg_getsize(HANDLE hf, int* width, int* height, LPSTR pszCode)
{
	if (!width || !height)
		return FALSE;

	*width = 0;
	*height = 0;

	BYTE buf[16];
	DWORD dw;

	BOOL bOK = FALSE;
	DWORD pos = SetFilePointer(hf, 2, NULL, FILE_BEGIN);
	while (1) {
		// �}�[�J�[���擾
		if (!ReadFile(hf, buf, 4, &dw, NULL) || dw < 4)
			break;

		// �}�[�J�[�ł͂Ȃ��H
		if (buf[0] != 0xFF)
			break;

		// �n�t�}�����R�[�h�t���[���H
		if (0xC0 <= buf[1] && buf[1] <= 0xC3) {
			bOK = TRUE;
			break;
		}

		DWORD posw = SetFilePointer(hf, (long)MAKEWORD(buf[3], buf[2]) - 2, NULL, FILE_CURRENT);
		if (pos == posw || posw == 0xFFFFFFFF)
			break;
		pos = posw;
	}

	if (bOK) {
		ReadFile(hf, buf, 5, &dw, NULL);
		*height = (int)MAKEWORD(buf[2], buf[1]);
		*width = (int)MAKEWORD(buf[4], buf[3]);

		if (pszCode)
			getcpcode(hf, pszCode);
	}
	return bOK;
}

extern "C"
BOOL WINAPI imgJpgGetImageSize(LPCTSTR pszName, int* width, int* height, LPSTR pszCode)
{
	BOOL bOK = FALSE;
	HANDLE hf = CreateFile(pszName, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
	if (hf != INVALID_HANDLE_VALUE) {
		bOK = jpg_getsize(hf, width, height, pszCode);
		CloseHandle(hf);
	}
	return bOK;
}


////////////////////////////////////////////////////////////////////////////////////////
//

static DWORD _xseek(HANDLE hf, long dist, int origin)
{
	DWORD pos = SetFilePointer(hf, 0, NULL, FILE_CURRENT);
	switch (origin) {
	case SEEK_SET: pos = SetFilePointer(hf, dist, NULL, FILE_BEGIN); break;
	case SEEK_CUR: pos = SetFilePointer(hf, dist, NULL, FILE_CURRENT); break;
	case SEEK_END: pos = SetFilePointer(hf, dist, NULL, FILE_END); break;
	}
	return pos;
}

static DWORD _xtell(HANDLE hf)
{
	return SetFilePointer(hf, 0, NULL, FILE_CURRENT);
}

static BOOL _xeof(HANDLE hf)
{
	DWORD cp = SetFilePointer(hf, 0, NULL, FILE_CURRENT);
	DWORD ep = SetFilePointer(hf, 0, NULL, FILE_END);
	SetFilePointer(hf, cp, NULL, FILE_BEGIN);
	return (ep <= cp);
}

int _xgetc(HANDLE hf)
{
	BYTE cb;
	DWORD len;
	if (ReadFile(hf, &cb, 1, &len, NULL))
		return (int)cb;
	return -1;
}

int _xgetw(HANDLE hf, bool le)
{
	BYTE cb[2];
	DWORD len;
	if (ReadFile(hf, &cb, 2, &len, NULL))
		return (le ? (int)(USHORT)((cb[1] << 8) | cb[0]) : (int)(USHORT)((cb[0] << 8) | cb[1]));
	return -1;
}

ULONG _xgetl(HANDLE hf, bool le)
{
	BYTE cb[4];
	DWORD len;
	if (ReadFile(hf, &cb, 4, &len, NULL))
		return (le ? (ULONG)((cb[3] << 24) | (cb[2] << 16) | (cb[1] << 8) | cb[0]) : (ULONG)((cb[0] << 24) | (cb[1] << 16) | (cb[2] << 8) | cb[3]));
	return (ULONG)-1;
}

static BOOL set_orientation(HANDLE hf, int orientation)
{
	long base = _xtell(hf);
	short order = _xgetw(hf, false);
	_xgetw(hf, false);			// Should be 42 for standard TIFF

	while (!_xeof(hf)) {
		long doff = _xgetl(hf, INTEL(order));
		if (!doff) break;

		_xseek(hf, doff + base, SEEK_SET);

		int entries = _xgetw(hf, INTEL(order));
		if (entries > 512) break;

		while (entries--) {
			if (_xeof(hf)) break;

			long save = _xtell(hf);
			int tag = _xgetw(hf, INTEL(order));
			if (tag == 0x112) {
				_xgetw(hf, true);			// type (is USHORT)
				_xgetl(hf, true);			// count (is 1)

				BYTE cb[2];
				if (INTEL(order)) {
					cb[0] = (BYTE)orientation;
					cb[1] = 0;
				}
				else {
					cb[0] = 0;
					cb[1] = (BYTE)orientation;
				}

				DWORD len;
				return WriteFile(hf, cb, 2, &len, NULL);

			}
			_xseek(hf, save + 12, SEEK_SET);
		}
	}
	return FALSE;
}

static BOOL jpeg_set_exif_orientation(HANDLE hf, int orientation)
{
	BOOL bOK = FALSE;
	_xseek(hf, 2, SEEK_SET);
	BYTE hdr[32];
	DWORD len;
	while (ReadFile(hf, hdr, 4, &len, NULL) && len == 4) {
		if (hdr[0] != 0xff || hdr[1] < 0xd0 || hdr[1] == 0xd9)
			break;

		if (hdr[1] == 0xe1) {
			if (!ReadFile(hf, hdr, 6, &len, NULL) || len != 6)
				break;

			if (!memcmp(hdr, "Exif\0\0", 6)) {
				bOK = set_orientation(hf, orientation);
				break;
			}
		}
		_xseek(hf, (hdr[2] << 8) + hdr[3] - 2, SEEK_CUR);
	}
	return bOK;
}

extern "C"
BOOL WINAPI imgJpgSetOrientation(LPCTSTR pszName, int orientation)
{
	BOOL bOK = FALSE;
	HANDLE hf = CreateFile(pszName, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, NULL);
	if (hf != INVALID_HANDLE_VALUE) {
		// �t�@�C�����t���擾
		FILETIME ftLastWrite;
		GetFileTime(hf, NULL, NULL, &ftLastWrite);

		BYTE cb[2];
		DWORD len;
		if (ReadFile(hf, cb, 2, &len, NULL) && len == 2 && cb[0] == 0xff && cb[1] == 0xd8)
			bOK = jpeg_set_exif_orientation(hf, orientation);

		// �t�@�C�����t�����ɖ߂�
		SetFileTime(hf, NULL, NULL, &ftLastWrite);
		CloseHandle(hf);
	}
	return bOK;
}
