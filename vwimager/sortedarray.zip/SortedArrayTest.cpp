#include "stdafx.h"
#include "SortedArray.h"
#include "SimpleArrayEx.h"

//The one and only ATL module instance
CExeModule _Module;


//A Simple function we use for sorting the test arrays we will use
int CompareInts(int& i1, int& i2)
{
  if (i1 > i2)
    return 1;
  else if (i1 < i2)
    return -1;
  else
    return 0;
}

//A functor version of the CompareInts function above
class CompareIntsClass
{
public:
  int operator()(int i1, int i2) const
  {
    if (i1 > i2)
      return 1;
    else if (i1 < i2)
      return -1;
    else
      return 0;
  }
};


int _tmain(int /*argc*/, TCHAR* /*argv*/[], TCHAR* /*envp*/[])
{
#ifndef SORTEDARRAY_ATL_ONLY
	//initialize MFC and print and error on failure (Note we must put up with some /analyze warnings for AfxWinInit even in VC 2008)
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
		return 1;
#endif

  // Test out the CSortedArray methods
  CSortedArray<int, int&> idata;
  idata.SetCompareFunction(CompareInts);
  int d = 7;
  idata.OrderedInsert(d);
  d = 3;
  idata.OrderedInsert(d);
  d = 4;
  idata.OrderedInsert(d);
  d = 5;
  idata.OrderedInsert(d);
  d = 2;
  idata.OrderedInsert(d);
  d = 11;
  idata.Add(d);
  d = 1;
  idata.Add(d);
  d = 2;
  idata.Add(d);
  d = 6;
  idata.Add(d);
  d = 3;
  idata.Add(d);

  idata.Sort();
  ATLASSERT(idata.GetSize() == 10);
  d = 11;
  CSA_INT nIndex = idata.Find(d);

  d = 6;
  nIndex = idata.Find(d);
  d = 3;
  nIndex = idata.Find(d);
  d = 2;
  nIndex = idata.Find(d);

  d = 88;
  nIndex = idata.Find(d);
  
  
  idata.UniqueSort();
  ATLASSERT(idata.GetSize() == 8); //Should have removed 1 duplicate "2" and 1 duplicate "3"


  nIndex; //To remove level 4 warning


  //Test out the CSimpleArrayEx class
  CSimpleArrayEx<int, int&> w;
  int value = 13;
  w.InsertAt(0, value, 2);
  value = 22;
  w.Add(value);

  CSimpleArrayEx<int, int&> x;
  value = 1;
  x.Add(value);
  value = 2;
  x.Add(value);
  w.InsertAt(1, &x);
  value = 33;
  w.InsertAt(5, value);

  ATLASSERT(w[0] == 13);
  ATLASSERT(w[1] == 1);
  ATLASSERT(w[2] == 2);
  ATLASSERT(w[3] == 13);
  ATLASSERT(w[4] == 22);
  ATLASSERT(w[5] == 33);

  ATLASSERT(w.GetSize() == 6);



  //Test performance of function pointer vs functor versions
  CSortedArray<int, int&> arr1;
  arr1.SetCompareFunction(CompareInts);

  CSortedArrayEx<int, int&, CompareIntsClass> arr2;

  int nItemsToAdd = 10000000;
  int i;

  LARGE_INTEGER c1,c2,c3,c4,cf;
  QueryPerformanceFrequency(&cf); 
  __int64 x1, x2, xx;
  xx = cf.QuadPart / 1000;

  _tprintf(_T("Testing sorting speed\n"));


  _tprintf(_T("..Inserting items into arrays\n"));

#ifndef SORTEDARRAY_ATL_ONLY
  arr1.SetSize(0, nItemsToAdd);
  arr2.SetSize(0, nItemsToAdd);
#endif

  for (i=nItemsToAdd; i>=0; i--)
  {
    arr1.Add(i);
    arr2.Add(i);
  }

  _tprintf(_T("..Sorting function pointer array\n"));
  QueryPerformanceCounter(&c1);
  
  arr1.Sort();

  QueryPerformanceCounter(&c2);


  _tprintf(_T("..Sorting functor array\n"));

  QueryPerformanceCounter(&c3);

  arr2.Sort();

  QueryPerformanceCounter(&c4);

  x1 = c2.QuadPart - c1.QuadPart; 
  x2 = c4.QuadPart - c3.QuadPart; 

  x1 /= xx;
  x2 /= xx;


  _tprintf(_T("..Time to sort function pointer array of size %d: %d ms\n"), nItemsToAdd, (int)x1);
  _tprintf(_T("..Time to sort functor array of size %d: %d ms\n"), nItemsToAdd, (int)x2);

  _tprintf(_T("..Sample Function pointer array elements --------------\n"));

  for(i=0; i< 30; i++)
  {
    _tprintf(_T("%d "), arr1[i]);
  }

  _tprintf(_T("..Sample Functor array elements -----------------------\n"));
  
  for(i=0; i< 30; i++)
  {
    _tprintf(_T("%d "), arr2[i]);
  }



  CSortedArray<int, int&> arr3;
  arr3.SetCompareFunction(CompareInts);

  CSortedArrayEx<int, int&, CompareIntsClass> arr4;

  _tprintf(_T("Testing OrderedInsert speed\n"));

  _tprintf(_T("..Inserting items into function pointer array (in ordered mode)\n"));

#ifndef SORTEDARRAY_ATL_ONLY
  arr3.SetSize(0, nItemsToAdd);
#endif

  QueryPerformanceCounter(&c1);
  for (i=0; i<nItemsToAdd; i++)
    arr3.OrderedInsert(i);
  QueryPerformanceCounter(&c2);



  _tprintf(_T("..Inserting items into functor array (in ordered mode)\n"));

#ifndef SORTEDARRAY_ATL_ONLY
  arr4.SetSize(0, nItemsToAdd);
#endif

  QueryPerformanceCounter(&c3);
  for (i=0; i<nItemsToAdd; i++)
    arr4.OrderedInsert(i);
  QueryPerformanceCounter(&c4);

  x1 = c2.QuadPart - c1.QuadPart; 
  x2 = c4.QuadPart - c3.QuadPart; 

  x1 /= xx;
  x2 /= xx;


  _tprintf(_T("..Time to ordered insert %d elements into function pointer array: %d ms\n"), nItemsToAdd, (int)x1);
  _tprintf(_T("..Time to ordered insert %d elements into functor array: %d ms\n"), nItemsToAdd, (int)x2);

  _tprintf(_T("..Sample Function pointer array elements --------------\n"));

  for(i=0; i< 30; i++)
  {
    _tprintf(_T("%d "), arr3[i]);
  }

  _tprintf(_T("..Sample Functor array elements ----------------------\n"));
  
  for(i=0; i< 30; i++)
  {
    _tprintf(_T("%d "), arr4[i]);
  }

  return 0;
}
