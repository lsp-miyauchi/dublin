#pragma once

#ifndef STRICT
#define STRICT
#endif

#ifndef WINVER
#define WINVER 0x0400
#endif

#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0400
#endif						

#ifndef _WIN32_IE
#define _WIN32_IE 0x0400
#endif
			

#define VC_EXTRALEAN

#define _ATL_CSTRING_EXPLICIT_CONSTRUCTORS	// some CString constructors will be explicit

#ifndef SORTEDARRAY_ATL_ONLY
#include <afxwin.h>
#include <afxtempl.h>
#endif

#include <atlbase.h>
class CExeModule : public CComModule
{
};
extern CExeModule _Module;
#include <atlcom.h>

#include <stdio.h>

