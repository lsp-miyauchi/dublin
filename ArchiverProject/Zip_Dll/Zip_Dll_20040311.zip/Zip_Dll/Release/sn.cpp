#include <windows.h>
#include <stdio.h>

#pragma comment(lib, "user32.lib")

void main(int argc, char** argv)
{
	if (argc > 1)
	{
		int i = 1;
		while (--argc > 0)
		{
			char name[MAX_PATH];
			GetShortPathName(argv[i], name, MAX_PATH);
			printf("%s --> %s\n", argv[i], name);
			i++;
		}
	}
}
