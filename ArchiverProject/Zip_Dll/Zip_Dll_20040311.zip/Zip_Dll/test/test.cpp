#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <string.h>
#include <commctrl.h>
#include <winver.h>

#define ZIP_DLL_NAME "LSPZIP.DLL\0"


/****************************************************************************

    FUNCTION: Main(int argc, char **argv)

****************************************************************************/

int main(int argc, char **argv)
{
	HINSTANCE hZipDll;
	char buf[MAX_PATH];
	int i, len;
	DWORD (WINAPI* pfnLock)(DWORD);
	int (WINAPI* pfnZip)(HWND, char*, char*, DWORD);

	hZipDll = LoadLibrary(ZIP_DLL_NAME);
	if (hZipDll == NULL)
	{
		char str[256];
		wsprintf (str, "Could not load %s", ZIP_DLL_NAME);
		printf("%s\n", str);
		return 0;
	}

	(FARPROC&)pfnLock = GetProcAddress(hZipDll, "ZipLocked");
	if (!pfnLock)
	{
		printf("Cannot get address of ZipLocked in lspzip.dll.");
		FreeLibrary(hZipDll);
		return 0;
	}
	(*pfnLock)(1);

	(FARPROC&)pfnZip = GetProcAddress(hZipDll, "Zip");
	if (!pfnZip)
	{
		printf("Cannot get address of Zip in lspzip.dll.");
		FreeLibrary(hZipDll);
		return 0;
	}

	len = 0;
	for (i = 1; i < argc; i++)
		len += sprintf(&buf[len], "%s ", argv[i]);

	LPSTR pResult;
	pResult = (LPSTR)GlobalAllocPtr(GHND, 0x8000);
	(*pfnZip)(GetFocus(), buf, NULL, 0);
	printf(pResult);
	GlobalFreePtr(pResult);

	FreeLibrary(hZipDll);
	return 0;
}
