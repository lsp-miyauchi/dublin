/*
 A very simplistic example of how to load the zip dll and make a call into it.
 Note that none of the command line options are implemented in this example.

 */

#define API

#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <string.h>
#include <direct.h>
#include "test.h"
#include "..\zipver.h"

#ifdef WIN32
#include <commctrl.h>
#include <winver.h>
#else
#include <ver.h>
#endif

#define ZIP_DLL_NAME "LSPZIP.DLL\0"


/****************************************************************************

    FUNCTION: Main(int argc, char **argv)

****************************************************************************/

int main(int argc, char **argv)
{
	HINSTANCE hZipDll;
	char buf[MAX_PATH];
	int i, len;
	int (WINAPI* pfnZip)(HWND, char*, char*, DWORD);

	hZipDll = LoadLibrary(ZIP_DLL_NAME);
	if (hZipDll == NULL)
	{
		char str[256];
		wsprintf (str, "Could not load %s", ZIP_DLL_NAME);
		printf("%s\n", str);
		return 0;
	}

	pfnZip = GetProcAddress(hZipDll, "Zip");
	if (!pfnZip)
	{
		printf("Cannot get address of Zip in lspzip.dll.");
		FreeLibrary(hZipDll);
		return 0;
	}

	len = 0;
	for (i = 1; i < argc; i++)
		len += sprintf(&buf[len], "%s ", argv[i]);

	(*pfnZip)(GetFocus(), buf, NULL, 0);

	FreeLibrary(hZipDll);
	return 0;
}
