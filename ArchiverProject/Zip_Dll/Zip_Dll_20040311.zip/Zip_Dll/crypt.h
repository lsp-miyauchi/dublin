/*
   crypt.h (full version) by Info-ZIP.   Last revised:  [see CR_VERSION_DATE]

   This header file is not copyrighted, and non-beta versions may be
   distributed without restriction.
 */

#ifndef __crypt_h   /* don't include more than once */
#define __crypt_h

#ifdef CRYPT
#  undef CRYPT
#endif
#define CRYPT  1    /* full version */

#ifdef CR_BETA
#  undef CR_BETA    /* this is not a beta release */
#endif

#define CR_MAJORVER        2
#define CR_MINORVER        8
#ifdef CR_BETA
#  define CR_BETA_VER      "c BETA"
#  define CR_VERSION_DATE  "05 July 1998"      /* last real code change */
#else
#  define CR_BETA_VER      ""
#  define CR_VERSION_DATE  "18 November 1998"  /* last public release date */
#  define CR_RELEASE
#endif

#ifndef __G         /* UnZip only, for now (DLL stuff) */
#  define __G
#  define __G__
#  define __GDEF
#  define __GPRO    void
#  define __GPRO__
#endif

#if defined(MSDOS) || defined(OS2) || defined(WIN32)
#  ifndef DOS_OS2_W32
#    define DOS_OS2_W32
#  endif
#endif

#if defined(DOS_OS2_W32) || defined(__human68k__)
#  ifndef DOS_H68_OS2_W32
#    define DOS_H68_OS2_W32
#  endif
#endif

#if defined(VM_CMS) || defined(MVS)
#  ifndef CMS_MVS
#    define CMS_MVS
#  endif
#endif

/* To allow combining of Zip and UnZip static libraries in a single binary,
 * the Zip and UnZip versions of the crypt core functions have to be named
 * differently.
 */
#ifdef ZIP
#  ifdef REALLY_SHORT_SYMS
#    define decrypt_byte   zdcrby
#  else
#    define decrypt_byte   zp_decrypt_byte
#  endif
#  define  update_keys     zp_update_keys
#  define  init_keys       zp_init_keys
#else /* !ZIP */
#  ifdef REALLY_SHORT_SYMS
#    define decrypt_byte   dcrbyt
#  endif
#endif /* ?ZIP */

/////////////////////////////////////////////////////////////////////
// K.Miyauchi 2000/09/16 �p�X���[�h�ő咷�� 255 �ɐݒ�
// #define IZ_PWLEN  80    /* input buffer size for reading encryption key */
#define IZ_PWLEN  255   /* input buffer size for reading encryption key */
#ifndef PWLEN           /* for compatibility with previous zcrypt release... */
#  define PWLEN IZ_PWLEN
#endif
#define RAND_HEAD_LEN  12       /* length of encryption random header */

/* the crc_32_tab array has to be provided externally for the crypt calculus */
#ifndef CRC_32_TAB                   /* UnZip provides this in globals.h */
extern ZCONST ulg* crc_32_tab;
#endif /* !CRC_32_TAB */

/* encode byte c, using temp t.  Warning: c must not have side effects. */
#define zencode(c,t)  (t=decrypt_byte(__G), update_keys(c), t^(c))

/* decode byte c in place */
#define zdecode(c)   update_keys(__G__ c ^= decrypt_byte(__G))

int  decrypt_byte OF((__GPRO));
int  update_keys OF((__GPRO__ int c));
void init_keys OF((__GPRO__ ZCONST char *passwd));

#ifdef ZIP
   void crypthead OF((ZCONST char *, ulg, FILE *));
#  ifdef UTIL
     int zipcloak OF((struct zlist*, FILE *, FILE *, ZCONST char *));
     int zipbare OF((struct zlist*, FILE *, FILE *, ZCONST char *));
#  else
     unsigned zfwrite OF((ZIPINFO*, zvoid *, extent, extent, FILE *));
#  endif
#endif /* ZIP */

#if (defined(UNZIP) && !defined(FUNZIP))
   int  decrypt OF((__GPRO__ ZCONST char *passwrd));
#endif

#ifdef FUNZIP
   extern int encrypted;
#  ifdef NEXTBYTE
#    undef NEXTBYTE
#  endif
#  define NEXTBYTE \
   (encrypted? update_keys(__G__ getc(G.in)^decrypt_byte(__G)) : getc(G.in))
#endif /* FUNZIP */

#endif /* !__crypt_h */
